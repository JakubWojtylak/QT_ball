var searchData=
[
  ['przesun',['przesun',['../classMainWidget.html#a6df60adf8e9c01f15a967932cb746c54',1,'MainWidget']]]
];
