var searchData=
[
  ['rpimmediaterefresh',['rpImmediateRefresh',['../classQCustomPlot.html#a45d61392d13042e712a956d27762aa39aa6eda645ccf1a60635df3e8b71ea6ae2',1,'QCustomPlot']]],
  ['rpqueuedrefresh',['rpQueuedRefresh',['../classQCustomPlot.html#a45d61392d13042e712a956d27762aa39acd6f1e590ea775d1ddee666428077f3e',1,'QCustomPlot']]],
  ['rpqueuedreplot',['rpQueuedReplot',['../classQCustomPlot.html#a45d61392d13042e712a956d27762aa39a019650c6ddf308f97e811fbfff207a8f',1,'QCustomPlot']]],
  ['rprefreshhint',['rpRefreshHint',['../classQCustomPlot.html#a45d61392d13042e712a956d27762aa39a49666a5854a68dbcca8b277b03331260',1,'QCustomPlot']]],
  ['rudotspercentimeter',['ruDotsPerCentimeter',['../namespaceQCP.html#a715d46153da230990aa887d0f0602452a4224e01f49b331489ad8cb12b619b229',1,'QCP']]],
  ['rudotsperinch',['ruDotsPerInch',['../namespaceQCP.html#a715d46153da230990aa887d0f0602452affb887d8efe79c39a1aca2acd7002afc',1,'QCP']]],
  ['rudotspermeter',['ruDotsPerMeter',['../namespaceQCP.html#a715d46153da230990aa887d0f0602452a707d005dea5c4ab694e4270d9c6094e8',1,'QCP']]]
];
