var searchData=
[
  ['zoom',['zoom',['../classQCPAxisRect.html#a5fc8460564e81dcc2a9343dc8bc1fe67',1,'QCPAxisRect::zoom(const QRectF &amp;pixelRect)'],['../classQCPAxisRect.html#a6a39fb3aea60a8c503bdcb3f0477d2f6',1,'QCPAxisRect::zoom(const QRectF &amp;pixelRect, const QList&lt; QCPAxis *&gt; &amp;affectedAxes)']]]
];
