var searchData=
[
  ['x_5faxis',['x_Axis',['../classDialog.html#aa0b8b6a5f69da0c051262423f2754401',1,'Dialog']]],
  ['xaxis',['xAxis',['../classQCustomPlot.html#a9a79cd0158a4c7f30cbc702f0fd800e4',1,'QCustomPlot']]],
  ['xaxis2',['xAxis2',['../classQCustomPlot.html#ada41599f22cad901c030f3dcbdd82fd9',1,'QCustomPlot']]]
];
