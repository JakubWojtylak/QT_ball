var searchData=
[
  ['reset',['reset',['../classMainWidget.html#a8320222b0090e6cd5550825cdab4c8aa',1,'MainWidget']]]
];
