var searchData=
[
  ['bracketstyle',['BracketStyle',['../classQCPSelectionDecoratorBracket.html#aa6d18517ec0553575bbef0de4252336e',1,'QCPSelectionDecoratorBracket::BracketStyle()'],['../classQCPItemBracket.html#a7ac3afd0b24a607054e7212047d59dbd',1,'QCPItemBracket::BracketStyle()']]]
];
