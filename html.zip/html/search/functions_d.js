var searchData=
[
  ['operator_2a_3d',['operator*=',['../classQCPVector2D.html#aa52a246d168f475a4231c7bdfdac7df1',1,'QCPVector2D::operator*=()'],['../classQCPRange.html#a6876aa9620ff2f0f7f1873f998372cef',1,'QCPRange::operator*=()']]],
  ['operator_2b_3d',['operator+=',['../classQCPVector2D.html#aa2c34754ce8839b2d074dec741783c5e',1,'QCPVector2D::operator+=()'],['../classQCPRange.html#afea7c1aa7d08f061cd9bd8832f957df8',1,'QCPRange::operator+=()'],['../classQCPDataSelection.html#a4584d4b0ea5c4f095bd7b70f88eb5d9d',1,'QCPDataSelection::operator+=(const QCPDataSelection &amp;other)'],['../classQCPDataSelection.html#a17058640d4e6f49984a0e7e42043df1b',1,'QCPDataSelection::operator+=(const QCPDataRange &amp;other)']]],
  ['operator_2d_3d',['operator-=',['../classQCPVector2D.html#a3a2e906bb924983bb801e89f28a3d566',1,'QCPVector2D::operator-=()'],['../classQCPRange.html#a95894bcb15a16a75ca564091374e2191',1,'QCPRange::operator-=()'],['../classQCPDataSelection.html#a66f9fab70b026baa64bf8e52fe5de07e',1,'QCPDataSelection::operator-=(const QCPDataSelection &amp;other)'],['../classQCPDataSelection.html#a8d18b20d20dde737eefc10967e31cf73',1,'QCPDataSelection::operator-=(const QCPDataRange &amp;other)']]],
  ['operator_2f_3d',['operator/=',['../classQCPVector2D.html#aefa55eb9282c066a330ca281881e0ec0',1,'QCPVector2D::operator/=()'],['../classQCPRange.html#a6137d8682b6835ace840730b4c1e2d63',1,'QCPRange::operator/=()']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../classQCPVector2D.html#a6c757af9671d925af4a36c2f58fb7234',1,'QCPVector2D::operator&lt;&lt;()'],['../classQCPRange.html#ab4b7d434541ec2e2e00ef3764dde90d8',1,'QCPRange::operator&lt;&lt;()'],['../classQCPDataRange.html#a486dd7af8a090ed069672e3510e6a082',1,'QCPDataRange::operator&lt;&lt;()'],['../classQCPDataSelection.html#aed65b8988afe6b03adeadf5edf663670',1,'QCPDataSelection::operator&lt;&lt;()']]],
  ['operator_3d',['operator=',['../classQCPColorMapData.html#afdf4dd1b2f5714234fe84709b85c2a8d',1,'QCPColorMapData']]],
  ['operator_3d_3d',['operator==',['../classQCPDataSelection.html#a664fa566569b17148abafd6b1dbbf347',1,'QCPDataSelection']]],
  ['opposite',['opposite',['../classQCPAxis.html#aa85ba73dfee6483e23825461b725e363',1,'QCPAxis']]],
  ['orientation',['orientation',['../classQCPAxis.html#ab988ef4538e2655bb77bd138189cd42e',1,'QCPAxis::orientation() const'],['../classQCPAxis.html#a9a68b3e45f1b1e33d4d807822342516c',1,'QCPAxis::orientation(AxisType type)']]],
  ['outerrect',['outerRect',['../classQCPLayoutElement.html#a2a32a12a6161c9dffbadeb9cc585510c',1,'QCPLayoutElement']]]
];
