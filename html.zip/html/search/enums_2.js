var searchData=
[
  ['chartstyle',['ChartStyle',['../classQCPFinancial.html#a0f800e21ee98d646dfc6f8f89d10ebfb',1,'QCPFinancial']]],
  ['colorinterpolation',['ColorInterpolation',['../classQCPColorGradient.html#ac5dca17cc24336e6ca176610e7f77fc1',1,'QCPColorGradient']]]
];
