var searchData=
[
  ['refreshpriority',['RefreshPriority',['../classQCustomPlot.html#a45d61392d13042e712a956d27762aa39',1,'QCustomPlot']]],
  ['resolutionunit',['ResolutionUnit',['../namespaceQCP.html#a715d46153da230990aa887d0f0602452',1,'QCP']]]
];
