var searchData=
[
  ['layer',['layer',['../classQCustomPlot.html#a0a96244e7773b242ef23c32b7bdfb159',1,'QCustomPlot::layer(const QString &amp;name) const'],['../classQCustomPlot.html#acbb570f4c24306e7c2324d40bfe157c2',1,'QCustomPlot::layer(int index) const']]],
  ['layerchanged',['layerChanged',['../classQCPLayerable.html#abbf8657cedea73ac1c3499b521c90eba',1,'QCPLayerable']]],
  ['layercount',['layerCount',['../classQCustomPlot.html#afa45d61e65292026f4c58c9c88c2cef0',1,'QCustomPlot']]],
  ['layout',['layout',['../classQCPLayoutElement.html#a4efdcbde9d28f410e5ef166c9d691deb',1,'QCPLayoutElement']]],
  ['layoutelementat',['layoutElementAt',['../classQCustomPlot.html#afaa1d304e0287d140fd238e90889ef3c',1,'QCustomPlot']]],
  ['left',['left',['../classQCPAxisRect.html#afb4a3de02046b20b9310bdb8fca781c3',1,'QCPAxisRect']]],
  ['legendclick',['legendClick',['../classQCustomPlot.html#a79cff0baafbca10a3aaf694d2d3b9ab3',1,'QCustomPlot']]],
  ['legenddoubleclick',['legendDoubleClick',['../classQCustomPlot.html#a0250f835c044521df1619b132288bca7',1,'QCustomPlot']]],
  ['length',['length',['../classQCPVector2D.html#a10adb5ab031fe94f0b64a3c5aefb552e',1,'QCPVector2D::length()'],['../classQCPDataRange.html#a1e7836058f755c6ab9f11996477b7150',1,'QCPDataRange::length()']]],
  ['lengthsquared',['lengthSquared',['../classQCPVector2D.html#a766585459d84cb149334fda1a498b2e5',1,'QCPVector2D']]],
  ['limititeratorstodatarange',['limitIteratorsToDataRange',['../classQCPDataContainer.html#aa1b36f5ae86a5a5a0b92141d3a0945c4',1,'QCPDataContainer']]],
  ['loadpreset',['loadPreset',['../classQCPColorGradient.html#aa0aeec1528241728b9671bf8e60b1622',1,'QCPColorGradient']]]
];
