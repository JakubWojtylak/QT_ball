var searchData=
[
  ['gradientpreset',['GradientPreset',['../classQCPColorGradient.html#aed6569828fee337023670272910c9072',1,'QCPColorGradient']]]
];
