var searchData=
[
  ['maxrange',['maxRange',['../classQCPRange.html#a5ca51e7a2dc5dc0d49527ab171fe1f4f',1,'QCPRange']]],
  ['minrange',['minRange',['../classQCPRange.html#ab46d3bc95030ee25efda41b89e2b616b',1,'QCPRange']]]
];
