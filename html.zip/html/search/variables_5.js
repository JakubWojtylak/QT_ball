var searchData=
[
  ['state',['state',['../classMainWidget.html#aad9c9c0b73a768fe201df0cef3c186b7',1,'MainWidget']]]
];
