var searchData=
[
  ['insetplacement',['InsetPlacement',['../classQCPLayoutInset.html#a8b9e17d9a2768293d2a7d72f5e298192',1,'QCPLayoutInset']]],
  ['interaction',['Interaction',['../namespaceQCP.html#a2ad6bb6281c7c2d593d4277b44c2b037',1,'QCP']]]
];
