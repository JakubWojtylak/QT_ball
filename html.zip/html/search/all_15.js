var searchData=
[
  ['wheelevent',['wheelEvent',['../classQCPLayerable.html#a47dfd7b8fd99c08ca54e09c362b6f022',1,'QCPLayerable::wheelEvent()'],['../classQCPAxis.html#aa850f195d7cc470c53809d0fff5e444d',1,'QCPAxis::wheelEvent()'],['../classQCPAxisRect.html#a93eeaa0c127d6d6fe8171b2455080262',1,'QCPAxisRect::wheelEvent()'],['../classQCPColorScale.html#a63cf19be184f6670c9495ad3a9a1baeb',1,'QCPColorScale::wheelEvent()']]],
  ['width',['width',['../classQCPAxisRect.html#a204645398a4f9d0b0189385c7c2cfb91',1,'QCPAxisRect']]],
  ['widthtype',['WidthType',['../classQCPBars.html#a65dbbf1ab41cbe993d71521096ed4649',1,'QCPBars::WidthType()'],['../classQCPFinancial.html#aef1761dda71a53dc5269685e9e492626',1,'QCPFinancial::WidthType()']]],
  ['wtabsolute',['wtAbsolute',['../classQCPBars.html#a65dbbf1ab41cbe993d71521096ed4649ab74315c9aa77df593c58dd25dfc0de35',1,'QCPBars::wtAbsolute()'],['../classQCPFinancial.html#aef1761dda71a53dc5269685e9e492626a0758d53bb6d7b4858e6bf8771edc934a',1,'QCPFinancial::wtAbsolute()']]],
  ['wtaxisrectratio',['wtAxisRectRatio',['../classQCPBars.html#a65dbbf1ab41cbe993d71521096ed4649a90bc09899361ad3422ff277f7c790ffe',1,'QCPBars::wtAxisRectRatio()'],['../classQCPFinancial.html#aef1761dda71a53dc5269685e9e492626a806518350ea5814d28c29b0056e33ecd',1,'QCPFinancial::wtAxisRectRatio()']]],
  ['wtplotcoords',['wtPlotCoords',['../classQCPBars.html#a65dbbf1ab41cbe993d71521096ed4649aad3cc60ae1bfb1160a30237bee9eaf10',1,'QCPBars::wtPlotCoords()'],['../classQCPFinancial.html#aef1761dda71a53dc5269685e9e492626af676bc8dbe700b96b333329c9dbfc30f',1,'QCPFinancial::wtPlotCoords()']]],
  ['wykres',['wykres',['../classwykres.html',1,'']]]
];
