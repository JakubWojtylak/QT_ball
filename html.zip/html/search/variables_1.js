var searchData=
[
  ['legend',['legend',['../classQCustomPlot.html#a4eadcd237dc6a09938b68b16877fa6af',1,'QCustomPlot']]]
];
