var searchData=
[
  ['wykres',['wykres',['../classwykres.html',1,'']]]
];
