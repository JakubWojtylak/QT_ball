var searchData=
[
  ['element',['element',['../classQCPLayoutGrid.html#a602b426609b4411cf6a93c3ddf3a381a',1,'QCPLayoutGrid']]],
  ['elementat',['elementAt',['../classQCPLayout.html#afa73ca7d859f8a3ee5c73c9b353d2a56',1,'QCPLayout::elementAt()'],['../classQCPLayoutGrid.html#a4288f174082555f6bd92021bdedb75dc',1,'QCPLayoutGrid::elementAt()'],['../classQCPLayoutInset.html#a881ca205605bae9c034733b808f93a02',1,'QCPLayoutInset::elementAt()']]],
  ['elementcount',['elementCount',['../classQCPLayout.html#a39d3e9ef5d9b82ab1885ba1cb9597e56',1,'QCPLayout::elementCount()'],['../classQCPLayoutGrid.html#a9a8942aface780a02445ebcf14c48513',1,'QCPLayoutGrid::elementCount()'],['../classQCPLayoutInset.html#a7f5aa4d48a2e844cfe6dd7ed8f0861df',1,'QCPLayoutInset::elementCount()']]],
  ['elements',['elements',['../classQCPMarginGroup.html#ac967a4dc5fe02ae44aeb43511d5e1bd4',1,'QCPMarginGroup::elements()'],['../classQCPLayoutElement.html#a76dec8cb31e498994a944d7647a43309',1,'QCPLayoutElement::elements()'],['../classQCPLayout.html#aca129722c019f91d3367046f80abfa77',1,'QCPLayout::elements()'],['../classQCPLayoutGrid.html#a7d5b968b4cf57393e9e387976d91f8f7',1,'QCPLayoutGrid::elements()'],['../classQCPAxisRect.html#a3aee067fd105f2fa8de9eb8024435ac5',1,'QCPAxisRect::elements()']]],
  ['end',['end',['../classQCPDataContainer.html#acf66dfad83fe041380f5e0491e7676f2',1,'QCPDataContainer']]],
  ['enforcetype',['enforceType',['../classQCPDataSelection.html#a17b84d852911531d229f4a76aa239a75',1,'QCPDataSelection']]],
  ['expand',['expand',['../classQCPRange.html#a0fa1bc8048be50d52bea93a8caf08305',1,'QCPRange::expand(const QCPRange &amp;otherRange)'],['../classQCPRange.html#a5fa977db0a4b7800075c629c62cf5e80',1,'QCPRange::expand(double includeCoord)']]],
  ['expanded',['expanded',['../classQCPRange.html#a9cbfb7cd06eac1839cae981e05c19633',1,'QCPRange::expanded(const QCPRange &amp;otherRange) const'],['../classQCPRange.html#af81d70f1add7233d73a19dcbe5decb2e',1,'QCPRange::expanded(double includeCoord) const'],['../classQCPDataRange.html#a36c8ad8acf177ffeb0a72c8d73030844',1,'QCPDataRange::expanded()']]],
  ['expandto',['expandTo',['../classQCPLayoutGrid.html#a886c0dcbabd51a45da399e044552b685',1,'QCPLayoutGrid']]]
];
