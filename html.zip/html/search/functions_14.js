var searchData=
[
  ['validrange',['validRange',['../classQCPRange.html#ab38bd4841c77c7bb86c9eea0f142dcc0',1,'QCPRange::validRange(double lower, double upper)'],['../classQCPRange.html#a801b964752eaad6219be9d8a651ec2b3',1,'QCPRange::validRange(const QCPRange &amp;range)']]],
  ['valuerange',['valueRange',['../classQCPDataContainer.html#a35a102dc2424d1228fc374d9313efbe9',1,'QCPDataContainer::valueRange()'],['../classQCPGraphData.html#a2f8dd30360356f66cc418a170a9f3792',1,'QCPGraphData::valueRange()'],['../classQCPCurveData.html#acf15deffd18d400651f8384a95dad9f8',1,'QCPCurveData::valueRange()'],['../classQCPBarsData.html#acf3e6479dacacd6c81eebe7d4cd62185',1,'QCPBarsData::valueRange()'],['../classQCPStatisticalBoxData.html#a1a2410fcf3d45fa3a1ad09e265b9bcad',1,'QCPStatisticalBoxData::valueRange()'],['../classQCPFinancialData.html#a164d5584eeeb9ba48b4b595ac2ac7fcf',1,'QCPFinancialData::valueRange()']]]
];
