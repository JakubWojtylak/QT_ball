var searchData=
[
  ['wheelevent',['wheelEvent',['../classQCPLayerable.html#a47dfd7b8fd99c08ca54e09c362b6f022',1,'QCPLayerable::wheelEvent()'],['../classQCPAxis.html#aa850f195d7cc470c53809d0fff5e444d',1,'QCPAxis::wheelEvent()'],['../classQCPAxisRect.html#a93eeaa0c127d6d6fe8171b2455080262',1,'QCPAxisRect::wheelEvent()'],['../classQCPColorScale.html#a63cf19be184f6670c9495ad3a9a1baeb',1,'QCPColorScale::wheelEvent()']]],
  ['width',['width',['../classQCPAxisRect.html#a204645398a4f9d0b0189385c7c2cfb91',1,'QCPAxisRect']]]
];
