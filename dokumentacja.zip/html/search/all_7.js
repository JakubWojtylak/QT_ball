var searchData=
[
  ['mainwidget',['MainWidget',['../classMainWidget.html',1,'']]],
  ['mainwindow',['MainWindow',['../classMainWindow.html',1,'']]]
];
