var searchData=
[
  ['x_5faxis',['x_Axis',['../classDialog.html#aa0b8b6a5f69da0c051262423f2754401',1,'Dialog']]],
  ['xyz',['xyz',['../classMainWindow.html#a24619cb8a370a51a5ec7549c497cd112',1,'MainWindow']]]
];
