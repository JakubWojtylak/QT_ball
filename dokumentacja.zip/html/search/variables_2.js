var searchData=
[
  ['discovery',['discovery',['../classDialog.html#a7a5a966705f13033597b6e40b4bc66a1',1,'Dialog']]],
  ['discovery_5fproduct_5fid',['discovery_product_id',['../classDialog.html#a97e001dff4a03fc6e4d63a5a0fa7b8f1',1,'Dialog']]],
  ['discovery_5fvendor_5fid',['discovery_vendor_id',['../classDialog.html#aff6a46c0884ecc1e95fd9c7375aec514',1,'Dialog']]]
];
