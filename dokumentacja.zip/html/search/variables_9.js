var searchData=
[
  ['x_5faxis',['x_Axis',['../classDialog.html#aa0b8b6a5f69da0c051262423f2754401',1,'Dialog']]]
];
