var searchData=
[
  ['projection',['projection',['../classMainWidget.html#ab024c87ad22e1a41ec1d33dbf011fa0a',1,'MainWidget']]],
  ['przesun',['przesun',['../classMainWidget.html#a6df60adf8e9c01f15a967932cb746c54',1,'MainWidget']]]
];
