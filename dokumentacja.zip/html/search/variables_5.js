var searchData=
[
  ['reset',['reset',['../classMainWidget.html#a8320222b0090e6cd5550825cdab4c8aa',1,'MainWidget']]],
  ['rotacja',['rotacja',['../classMainWidget.html#aa834d062e80c28cd23f66d3f01a688f4',1,'MainWidget']]]
];
