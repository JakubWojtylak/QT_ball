var searchData=
[
  ['vertexdata',['VertexData',['../structVertexData.html',1,'']]],
  ['vx',['vX',['../classMainWidget.html#a91986f4cd0a536889c4697eb81fb82c1',1,'MainWidget']]],
  ['vy',['vY',['../classMainWidget.html#abfd21f44f83f520d2b020a36e73d88c1',1,'MainWidget']]],
  ['vz',['vZ',['../classMainWidget.html#ac832d7564e43ed2d6e2a03c651a7bf27',1,'MainWidget']]]
];
