var searchData=
[
  ['handleplay',['handlePlay',['../classMainWindow.html#aa2f20eff28cfa46cda4f0e6d26f9786a',1,'MainWindow']]],
  ['handlereset',['handleReset',['../classMainWindow.html#afd15849018e00f45a44f404dd0805f72',1,'MainWindow']]],
  ['handlestop',['handleStop',['../classMainWindow.html#aae0a812a7ffebdce14b504f1d3e722c7',1,'MainWindow']]]
];
