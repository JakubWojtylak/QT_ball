var indexSectionsWithContent =
{
  0: "abdfghimprstuvwxy",
  1: "dgmvw",
  2: "dfg",
  3: "dhirux",
  4: "abdiprstvxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

