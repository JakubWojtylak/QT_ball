var searchData=
[
  ['serialbuffer',['serialBuffer',['../classDialog.html#ac1227694c4e6d36bd406360dae0cb7bc',1,'Dialog']]],
  ['serialdata',['serialData',['../classDialog.html#a2f4d0b4d440bbc32668af9886220ddc7',1,'Dialog']]],
  ['state',['state',['../classMainWidget.html#aad9c9c0b73a768fe201df0cef3c186b7',1,'MainWidget']]]
];
