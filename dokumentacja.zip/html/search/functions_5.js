var searchData=
[
  ['xyz',['xyz',['../classMainWindow.html#a24619cb8a370a51a5ec7549c497cd112',1,'MainWindow']]]
];
