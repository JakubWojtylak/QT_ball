var searchData=
[
  ['read',['read',['../classDialog.html#ad766f1df658ea06808d040a19878f4f9',1,'Dialog']]],
  ['readserial',['readserial',['../classMainWindow.html#a3ae46800a65ccfe4467ccff0da526e57',1,'MainWindow::readserial()'],['../classDialog.html#a9dad20f00c0ea2dbf0b8a725a5fb8a55',1,'Dialog::readSerial()']]],
  ['reset',['reset',['../classMainWidget.html#a8320222b0090e6cd5550825cdab4c8aa',1,'MainWidget']]],
  ['rotacja',['rotacja',['../classMainWidget.html#aa834d062e80c28cd23f66d3f01a688f4',1,'MainWidget']]]
];
