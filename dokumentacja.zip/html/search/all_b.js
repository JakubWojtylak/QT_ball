var searchData=
[
  ['texture',['texture',['../classMainWidget.html#acc21b7eeeca01d94b5cd6d7ec079cfe0',1,'MainWidget']]]
];
