var searchData=
[
  ['updateaxisx',['updateAxisX',['../classDialog.html#a193d23a252d0fdae0fbf7bafe26b5436',1,'Dialog']]],
  ['updateaxisy',['updateAxisY',['../classDialog.html#a80b79327f63cc80a253c3c728101fba8',1,'Dialog']]]
];
